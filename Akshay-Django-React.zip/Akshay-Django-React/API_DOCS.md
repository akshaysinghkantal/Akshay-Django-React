# API Documentation

## GraphQL Endpoint
- URL: `http://localhost:8000/graphql/`
- Playground: GraphiQL enabled at the same endpoint

## Main Queries
### List Projects for an Organization
```graphql
query Projects($organizationId: ID!) {
  projects(organizationId: $organizationId) {
    id
    name
    description
    status
    dueDate
  }
}
```

### List Tasks for a Project
```graphql
query Tasks($projectId: ID!) {
  tasks(projectId: $projectId) {
    id
    title
    description
    status
    assigneeEmail
    dueDate
  }
}
```

### List Comments for a Task
```graphql
query TaskComments($taskId: ID!) {
  taskComments(taskId: $taskId) {
    id
    content
    authorEmail
    timestamp
  }
}
```

### Project Statistics
```graphql
query ProjectStats($projectId: ID!) {
  projectStats(projectId: $projectId) {
    taskCount
    completedTasks
    completionRate
  }
}
```

## Main Mutations
### Create Project
```graphql
mutation CreateProject($organizationId: ID!, $name: String!, $description: String, $status: String!, $dueDate: Date) {
  createProject(organizationId: $organizationId, name: $name, description: $description, status: $status, dueDate: $dueDate) {
    project {
      id
      name
      description
      status
      dueDate
    }
  }
}
```

### Update Project
```graphql
mutation UpdateProject($id: ID!, $organizationId: ID!, $name: String, $description: String, $status: String, $dueDate: Date) {
  updateProject(id: $id, organizationId: $organizationId, name: $name, description: $description, status: $status, dueDate: $dueDate) {
    project {
      id
      name
      description
      status
      dueDate
    }
  }
}
```

### Create Task
```graphql
mutation CreateTask($projectId: ID!, $title: String!, $description: String, $status: String!, $assigneeEmail: String, $dueDate: Date) {
  createTask(projectId: $projectId, title: $title, description: $description, status: $status, assigneeEmail: $assigneeEmail, dueDate: $dueDate) {
    task {
      id
      title
      description
      status
      assigneeEmail
      dueDate
    }
  }
}
```

### Update Task
```graphql
mutation UpdateTask($id: ID!, $projectId: ID!, $title: String, $description: String, $status: String, $assigneeEmail: String, $dueDate: Date) {
  updateTask(id: $id, projectId: $projectId, title: $title, description: $description, status: $status, assigneeEmail: $assigneeEmail, dueDate: $dueDate) {
    task {
      id
      title
      description
      status
      assigneeEmail
      dueDate
    }
  }
}
```

### Add Comment to Task
```graphql
mutation AddTaskComment($taskId: ID!, $content: String!, $authorEmail: String!) {
  addTaskComment(taskId: $taskId, content: $content, authorEmail: $authorEmail) {
    comment {
      id
      content
      authorEmail
      timestamp
    }
  }
}
```

## Schema Overview
- See `backend/core/schema.py` for full schema and type definitions.
- All queries and mutations require organization/project/task context for multi-tenancy.
- Error and loading states are handled in the frontend using Apollo Client and Material UI.
