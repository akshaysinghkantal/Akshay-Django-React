# Setup Instructions

## Prerequisites
- OS: Linux (tested on Ubuntu)
- Python 3.12+
- Node.js 18+
- PostgreSQL

## Backend Setup (Django + GraphQL)
1. Clone or unzip the project and navigate to the project folder:
   ```bash
   cd Akshay-Django-React
   ```
2. Create and activate a Python virtual environment:
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   ```
3. Install backend dependencies:
   ```bash
   pip install -r requirements.txt
   # If requirements.txt is missing, run:
   pip install django psycopg2-binary graphene-django django-cors-headers
   ```
4. Install and configure PostgreSQL:
   ```bash
   sudo apt update
   sudo apt install postgresql postgresql-contrib
   sudo -u postgres psql
   CREATE DATABASE project_management;
   CREATE USER postgres WITH PASSWORD 'newpassword';
   GRANT ALL PRIVILEGES ON DATABASE project_management TO postgres;
   \q
   sudo service postgresql start
   ```
5. Update `backend/settings.py` with your database credentials if needed.
6. Run migrations:
   ```bash
   cd backend
   python3 manage.py makemigrations
   python3 manage.py migrate
   ```
7. Create a superuser for admin access:
   ```bash
   python3 manage.py createsuperuser
   ```
8. Start the backend server:
   ```bash
   python3 manage.py runserver
   ```
   - Access GraphQL API at [http://localhost:8000/graphql/](http://localhost:8000/graphql/)
   - Access Django admin at [http://localhost:8000/admin/](http://localhost:8000/admin/)

## Frontend Setup (React + TypeScript + Material UI)
1. Navigate to the frontend folder:
   ```bash
   cd ../frontend
   ```
2. Install frontend dependencies:
   ```bash
   npm install
   npm install @mui/material @emotion/react @emotion/styled @apollo/client graphql @mui/icons-material
   ```
3. Start the frontend development server:
   ```bash
   npm start
   ```
   - Access the app at [http://localhost:3000](http://localhost:3000)

## Testing the Application
1. Go to Django admin ([http://localhost:8000/admin/](http://localhost:8000/admin/)) and log in with your superuser.
2. Add an Organization (name, slug, contact email).
3. Use the Organization ID in the frontend (default is 1, update in `src/App.tsx` if needed).
4. Test all features: create/view projects, add/edit tasks, add/view comments.

## Notes
- Ensure both backend and frontend servers are running for full functionality.
- For troubleshooting, see README.md and comments in code files.
- For API details, see API_DOCS.md. For technical summary, see TECH_SUMMARY.md.
