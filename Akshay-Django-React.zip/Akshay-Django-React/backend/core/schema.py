import graphene
from graphene_django import DjangoObjectType
from .models import Organization, Project, Task, TaskComment

class OrganizationType(DjangoObjectType):
    class Meta:
        model = Organization
        fields = ("id", "name", "slug", "contact_email", "created_at")

class ProjectType(DjangoObjectType):
    class Meta:
        model = Project
        fields = ("id", "organization", "name", "description", "status", "due_date", "created_at")

class TaskType(DjangoObjectType):
    class Meta:
        model = Task
        fields = ("id", "project", "title", "description", "status", "assignee_email", "due_date", "created_at")

class TaskCommentType(DjangoObjectType):
    class Meta:
        model = TaskComment
        fields = ("id", "task", "content", "author_email", "timestamp")

class ProjectStatsType(graphene.ObjectType):
    project_id = graphene.ID()
    task_count = graphene.Int()
    completed_tasks = graphene.Int()
    completion_rate = graphene.Float()

class Query(graphene.ObjectType):
    organizations = graphene.List(OrganizationType)
    projects = graphene.List(ProjectType, organization_id=graphene.ID(required=True))
    tasks = graphene.List(TaskType, project_id=graphene.ID(required=True))
    task_comments = graphene.List(TaskCommentType, task_id=graphene.ID(required=True))
    project_stats = graphene.Field(ProjectStatsType, project_id=graphene.ID(required=True))

    def resolve_organizations(root, info):
        return Organization.objects.all()

    def resolve_projects(root, info, organization_id):
        return Project.objects.filter(organization_id=organization_id)

    def resolve_tasks(root, info, project_id):
        return Task.objects.filter(project_id=project_id)

    def resolve_task_comments(root, info, task_id):
        return TaskComment.objects.filter(task_id=task_id)

    def resolve_project_stats(root, info, project_id):
        project = Project.objects.get(id=project_id)
        total = project.tasks.count()
        completed = project.tasks.filter(status='DONE').count()
        rate = (completed / total) * 100 if total > 0 else 0.0
        return ProjectStatsType(
            project_id=project_id,
            task_count=total,
            completed_tasks=completed,
            completion_rate=rate
        )

class CreateProject(graphene.Mutation):
    project = graphene.Field(ProjectType)

    class Arguments:
        organization_id = graphene.ID(required=True)
        name = graphene.String(required=True)
        description = graphene.String()
        status = graphene.String(required=True)
        due_date = graphene.types.datetime.Date()

    def mutate(self, info, organization_id, name, description=None, status=None, due_date=None):
        org = Organization.objects.get(id=organization_id)
        project = Project.objects.create(
            organization=org,
            name=name,
            description=description or "",
            status=status,
            due_date=due_date
        )
        return CreateProject(project=project)

class UpdateProject(graphene.Mutation):
    project = graphene.Field(ProjectType)

    class Arguments:
        id = graphene.ID(required=True)
        organization_id = graphene.ID(required=True)
        name = graphene.String()
        description = graphene.String()
        status = graphene.String()
        due_date = graphene.types.datetime.Date()

    def mutate(self, info, id, organization_id, name=None, description=None, status=None, due_date=None):
        project = Project.objects.get(id=id, organization_id=organization_id)
        if name: project.name = name
        if description: project.description = description
        if status: project.status = status
        if due_date: project.due_date = due_date
        project.save()
        return UpdateProject(project=project)

class CreateTask(graphene.Mutation):
    task = graphene.Field(TaskType)

    class Arguments:
        project_id = graphene.ID(required=True)
        title = graphene.String(required=True)
        description = graphene.String()
        status = graphene.String(required=True)
        assignee_email = graphene.String()
        due_date = graphene.types.datetime.Date()

    def mutate(self, info, project_id, title, description=None, status=None, assignee_email=None, due_date=None):
        project = Project.objects.get(id=project_id)
        task = Task.objects.create(
            project=project,
            title=title,
            description=description or "",
            status=status,
            assignee_email=assignee_email or "",
            due_date=due_date
        )
        return CreateTask(task=task)

class UpdateTask(graphene.Mutation):
    task = graphene.Field(TaskType)

    class Arguments:
        id = graphene.ID(required=True)
        project_id = graphene.ID(required=True)
        title = graphene.String()
        description = graphene.String()
        status = graphene.String()
        assignee_email = graphene.String()
        due_date = graphene.types.datetime.Date()

    def mutate(self, info, id, project_id, title=None, description=None, status=None, assignee_email=None, due_date=None):
        task = Task.objects.get(id=id, project_id=project_id)
        if title: task.title = title
        if description: task.description = description
        if status: task.status = status
        if assignee_email: task.assignee_email = assignee_email
        if due_date: task.due_date = due_date
        task.save()
        return UpdateTask(task=task)

class AddTaskComment(graphene.Mutation):
    comment = graphene.Field(TaskCommentType)

    class Arguments:
        task_id = graphene.ID(required=True)
        content = graphene.String(required=True)
        author_email = graphene.String(required=True)

    def mutate(self, info, task_id, content, author_email):
        task = Task.objects.get(id=task_id)
        comment = TaskComment.objects.create(
            task=task,
            content=content,
            author_email=author_email
        )
        return AddTaskComment(comment=comment)

class Mutation(graphene.ObjectType):
    create_project = CreateProject.Field()
    update_project = UpdateProject.Field()
    create_task = CreateTask.Field()
    update_task = UpdateTask.Field()
    add_task_comment = AddTaskComment.Field()

schema = graphene.Schema(query=Query, mutation=Mutation)
