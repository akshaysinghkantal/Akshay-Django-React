import React, { useState } from "react";
import logo from './logo.svg';
import './App.css';
import { Container, Typography, Box, CircularProgress, TextField, Dialog, DialogTitle, DialogContent, DialogActions, IconButton, Snackbar } from "@mui/material";
import { useQuery, gql, useMutation } from "@apollo/client";
import { Alert, Button } from "@mui/material";
import AddIcon from "@mui/icons-material/Add";
import CloseIcon from "@mui/icons-material/Close";

// Project interface
export interface Project {
  id: string;
  name: string;
  description: string;
  status: "ACTIVE" | "COMPLETED" | "ON_HOLD";
  dueDate?: string;
}

// Task interface
export interface Task {
  id: string;
  title: string;
  description: string;
  status: "TODO" | "IN_PROGRESS" | "DONE";
  assigneeEmail: string;
  dueDate?: string;
}

// Comment interface
export interface TaskComment {
  id: string;
  content: string;
  authorEmail: string;
  timestamp: string;
}

const PROJECTS_QUERY = gql`
  query Projects($organizationId: ID!) {
    projects(organizationId: $organizationId) {
      id
      name
      description
      status
      dueDate
    }
  }
`;

const CREATE_PROJECT_MUTATION = gql`
  mutation CreateProject($organizationId: ID!, $name: String!, $description: String, $status: String!, $dueDate: Date) {
    createProject(organizationId: $organizationId, name: $name, description: $description, status: $status, dueDate: $dueDate) {
      project {
        id
        name
        description
        status
        dueDate
      }
    }
  }
`;

const TASKS_QUERY = gql`
  query Tasks($projectId: ID!) {
    tasks(projectId: $projectId) {
      id
      title
      description
      status
      assigneeEmail
      dueDate
    }
  }
`;

const ADD_TASK_MUTATION = gql`
  mutation CreateTask($projectId: ID!, $title: String!, $description: String, $status: String!, $assigneeEmail: String, $dueDate: Date) {
    createTask(projectId: $projectId, title: $title, description: $description, status: $status, assigneeEmail: $assigneeEmail, dueDate: $dueDate) {
      task {
        id
        title
        description
        status
        assigneeEmail
        dueDate
      }
    }
  }
`;

const ADD_COMMENT_MUTATION = gql`
  mutation AddTaskComment($taskId: ID!, $content: String!, $authorEmail: String!) {
    addTaskComment(taskId: $taskId, content: $content, authorEmail: $authorEmail) {
      comment {
        id
        content
        authorEmail
        timestamp
      }
    }
  }
`;

const COMMENTS_QUERY = gql`
  query TaskComments($taskId: ID!) {
    taskComments(taskId: $taskId) {
      id
      content
      authorEmail
      timestamp
    }
  }
`;

const ORGANIZATION_ID = "1"; // Replace with actual org ID or selection logic

const statusColors: Record<Project["status"], string> = {
  ACTIVE: "#1976d2",
  COMPLETED: "#2e7d32",
  ON_HOLD: "#ed6c02",
};

const statusOptions = ["ACTIVE", "COMPLETED", "ON_HOLD"];

const taskStatusOptions = ["TODO", "IN_PROGRESS", "DONE"];

const ProjectForm: React.FC<{ onCreated: () => void }> = ({ onCreated }) => {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [status, setStatus] = useState("ACTIVE");
  const [dueDate, setDueDate] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const [createProject, { loading }] = useMutation(CREATE_PROJECT_MUTATION, {
    onCompleted: () => {
      setSuccess(true);
      setOpen(false);
      onCreated();
      setName("");
      setDescription("");
      setStatus("ACTIVE");
      setDueDate("");
    },
    onError: (err) => setError(err.message),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError("Project name is required.");
      return;
    }
    createProject({
      variables: {
        organizationId: ORGANIZATION_ID,
        name,
        description,
        status,
        dueDate: dueDate || null,
      },
      optimisticResponse: {
        createProject: {
          project: {
            id: Math.random().toString(),
            name,
            description,
            status,
            dueDate,
            __typename: "ProjectType",
          },
          __typename: "CreateProject",
        },
      },
    });
  };

  return (
    <>
      <IconButton color="primary" onClick={() => setOpen(true)} size="large">
        <AddIcon />
      </IconButton>
      <Dialog open={open} onClose={() => setOpen(false)}>
        <DialogTitle>Create Project</DialogTitle>
        <form onSubmit={handleSubmit}>
          <DialogContent>
            <TextField
              label="Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              fullWidth
              required
              margin="dense"
            />
            <TextField
              label="Description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              fullWidth
              margin="dense"
            />
            <TextField
              label="Status"
              select
              SelectProps={{ native: true }}
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              fullWidth
              margin="dense"
            >
              {statusOptions.map((opt) => (
                <option key={opt} value={opt}>{opt}</option>
              ))}
            </TextField>
            <TextField
              label="Due Date"
              type="date"
              value={dueDate}
              onChange={(e) => setDueDate(e.target.value)}
              fullWidth
              margin="dense"
              InputLabelProps={{ shrink: true }}
            />
            {error && <Alert severity="error" sx={{ mt: 2 }}>{error}</Alert>}
          </DialogContent>
          <DialogActions>
            <IconButton onClick={() => setOpen(false)}>
              <CloseIcon />
            </IconButton>
            <Button type="submit" variant="contained" disabled={loading}>
              {loading ? <CircularProgress size={24} /> : "Create"}
            </Button>
          </DialogActions>
        </form>
      </Dialog>
      <Snackbar
        open={success}
        autoHideDuration={3000}
        onClose={() => setSuccess(false)}
        message="Project created successfully!"
      />
    </>
  );
};

const TaskBoard: React.FC<{ projectId: string }> = ({ projectId }) => {
  const { data, loading, error, refetch } = useQuery(TASKS_QUERY, {
    variables: { projectId },
  });
  const [addTask] = useMutation(ADD_TASK_MUTATION, { onCompleted: refetch });
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [status, setStatus] = useState("TODO");
  const [assigneeEmail, setAssigneeEmail] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [errorMsg, setErrorMsg] = useState("");

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setErrorMsg("Task title is required.");
      return;
    }
    addTask({
      variables: {
        projectId,
        title,
        description,
        status,
        assigneeEmail,
        dueDate: dueDate || null,
      },
      optimisticResponse: {
        createTask: {
          task: {
            id: Math.random().toString(),
            title,
            description,
            status,
            assigneeEmail,
            dueDate,
            __typename: "TaskType",
          },
          __typename: "CreateTask",
        },
      },
    });
    setTitle("");
    setDescription("");
    setStatus("TODO");
    setAssigneeEmail("");
    setDueDate("");
    setErrorMsg("");
  };

  return (
    <Box mt={4}>
      <Typography variant="h5" gutterBottom>
        Tasks
      </Typography>
      <form onSubmit={handleAddTask} style={{ marginBottom: 16 }}>
        <Box display="flex" gap={2} flexWrap="wrap">
          <TextField label="Title" value={title} onChange={e => setTitle(e.target.value)} required />
          <TextField label="Description" value={description} onChange={e => setDescription(e.target.value)} />
          <TextField label="Status" select SelectProps={{ native: true }} value={status} onChange={e => setStatus(e.target.value)}>
            {taskStatusOptions.map(opt => <option key={opt} value={opt}>{opt}</option>)}
          </TextField>
          <TextField label="Assignee Email" value={assigneeEmail} onChange={e => setAssigneeEmail(e.target.value)} />
          <TextField label="Due Date" type="date" value={dueDate} onChange={e => setDueDate(e.target.value)} InputLabelProps={{ shrink: true }} />
          <Button type="submit" variant="contained">Add Task</Button>
        </Box>
        {errorMsg && <Alert severity="error" sx={{ mt: 2 }}>{errorMsg}</Alert>}
      </form>
      {loading && <CircularProgress />}
      {error && <Alert severity="error">{error.message}</Alert>}
      <Box display="flex" flexDirection="column" gap={2}>
        {data?.tasks?.map((task: Task) => (
          <TaskCard key={task.id} task={task} />
        ))}
      </Box>
    </Box>
  );
};

const TaskCard: React.FC<{ task: Task }> = ({ task }) => {
  const [comment, setComment] = useState("");
  const [authorEmail, setAuthorEmail] = useState("");
  const [addComment] = useMutation(ADD_COMMENT_MUTATION);
  const [success, setSuccess] = useState(false);
  const { data: commentsData, loading: commentsLoading, error: commentsError, refetch: refetchComments } = useQuery(COMMENTS_QUERY, {
    variables: { taskId: task.id },
  });

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!comment.trim() || !authorEmail.trim()) return;
    addComment({
      variables: {
        taskId: task.id,
        content: comment,
        authorEmail,
      },
      optimisticResponse: {
        addTaskComment: {
          comment: {
            id: Math.random().toString(),
            content: comment,
            authorEmail,
            timestamp: new Date().toISOString(),
            __typename: "TaskCommentType",
          },
          __typename: "AddTaskComment",
        },
      },
      onCompleted: () => {
        setSuccess(true);
        setComment("");
        setAuthorEmail("");
        refetchComments();
      },
    });
  };

  return (
    <Box p={2} borderRadius={2} boxShadow={1} bgcolor="#f9f9f9">
      <Typography variant="subtitle1">{task.title}</Typography>
      <Typography variant="body2" color="text.secondary">{task.description}</Typography>
      <Typography variant="caption" color="text.secondary">Status: {task.status}</Typography>
      <Typography variant="caption" color="text.secondary">Assignee: {task.assigneeEmail || "N/A"}</Typography>
      <Typography variant="caption" color="text.secondary">Due: {task.dueDate || "N/A"}</Typography>
      <form onSubmit={handleAddComment} style={{ marginTop: 8 }}>
        <Box display="flex" gap={1} alignItems="center">
          <TextField label="Comment" value={comment} onChange={e => setComment(e.target.value)} size="small" />
          <TextField label="Your Email" value={authorEmail} onChange={e => setAuthorEmail(e.target.value)} size="small" />
          <Button type="submit" variant="outlined" size="small">Add Comment</Button>
        </Box>
      </form>
      <Snackbar open={success} autoHideDuration={2000} onClose={() => setSuccess(false)} message="Comment added!" />
      <Box mt={2}>
        <Typography variant="subtitle2">Comments</Typography>
        {commentsLoading && <CircularProgress size={16} />}
        {commentsError && <Alert severity="error">{commentsError.message}</Alert>}
        <Box display="flex" flexDirection="column" gap={1}>
          {commentsData?.taskComments?.map((c: TaskComment) => (
            <Box key={c.id} p={1} bgcolor="#fff" borderRadius={1} boxShadow={1}>
              <Typography variant="body2">{c.content}</Typography>
              <Typography variant="caption" color="text.secondary">
                {c.authorEmail} • {new Date(c.timestamp).toLocaleString()}
              </Typography>
            </Box>
          ))}
        </Box>
      </Box>
    </Box>
  );
};

const ProjectDashboard: React.FC = () => {
  const { data, loading, error, refetch } = useQuery(PROJECTS_QUERY, {
    variables: { organizationId: ORGANIZATION_ID },
  });

  // Add a sample projectId for demonstration (replace with selection logic)
  const sampleProjectId = data?.projects?.[0]?.id || "1";

  return (
    <Container maxWidth="md">
      <Typography variant="h4" gutterBottom>
        Project Dashboard
      </Typography>
      <Box display="flex" alignItems="center" mb={2}>
        <ProjectForm onCreated={refetch} />
        <Button variant="contained" onClick={() => refetch()} sx={{ ml: 2 }}>
          Refresh
        </Button>
      </Box>
      {loading && (
        <Box display="flex" justifyContent="center" alignItems="center" height={200}>
          <CircularProgress />
        </Box>
      )}
      {error && <Alert severity="error">{error.message}</Alert>}
      <Box display="flex" flexDirection="column" gap={2}>
        {data?.projects?.map((project: Project) => (
          <Box
            key={project.id}
            p={2}
            borderRadius={2}
            boxShadow={2}
            bgcolor="#fff"
            display="flex"
            flexDirection="column"
            gap={1}
            sx={{ transition: "box-shadow 0.3s" }}
          >
            <Box display="flex" alignItems="center" gap={1}>
              <Box
                width={12}
                height={12}
                borderRadius="50%"
                bgcolor={statusColors[project.status]}
                mr={1}
              />
              <Typography variant="h6">{project.name}</Typography>
              <Typography variant="caption" color="text.secondary" ml={2}>
                {project.status}
              </Typography>
            </Box>
            <Typography variant="body2" color="text.secondary">
              {project.description}
            </Typography>
            <Typography variant="caption" color="text.secondary">
              Due: {project.dueDate || "N/A"}
            </Typography>
            {/* Task Board for the first project (demo) */}
            {project.id === sampleProjectId && <TaskBoard projectId={project.id} />}
          </Box>
        ))}
      </Box>
    </Container>
  );
};

function App() {
  return <ProjectDashboard />;
}

export default App;
