# Frontend Setup (React + TypeScript + Material UI)

## UI Framework Switch
- Removed TailwindCSS due to compatibility issues with v4 CLI and PostCSS.
- Switched to Material UI (MUI) for modern, responsive UI components.
- Installed with:
  ```bash
  npm install @mui/material @emotion/react @emotion/styled
  ```

## Project Structure
- All frontend code is in `Akshay-Django-React/frontend`.
- Main entry: `src/App.tsx`, global styles: `src/index.css`.
- MUI components will be used for all UI features.

## How to Start Frontend
```bash
cd Akshay-Django-React/frontend
npm start
```

## Next Steps
- Scaffold Project Dashboard and Task Management UI using MUI.
- Integrate Apollo Client for GraphQL backend communication.
- Remove any leftover TailwindCSS config files (tailwind.config.js, postcss.config.js) if not needed.

## Troubleshooting
- If you see errors about missing dependencies, run `npm install`.
- For MUI documentation, visit https://mui.com/

## Learn More

You can learn more in the [Create React App documentation](https://facebook.github.io/create-react-app/docs/getting-started).

To learn React, check out the [React documentation](https://reactjs.org/).
